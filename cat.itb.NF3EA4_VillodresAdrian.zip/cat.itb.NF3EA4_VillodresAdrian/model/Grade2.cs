﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cat.itb.NF3EA1_VillodresAdrian.Model
{
    [Serializable]
    public class Grade2
    {
        public Date date { get; set; }
        public string grade { get; set; }
        public int score { get; set; }
    }
}
